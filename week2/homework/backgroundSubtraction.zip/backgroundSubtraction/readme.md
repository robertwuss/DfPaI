# Background Subtraction

Create a program that removes the background from a webcam feed. This is done by subracting the background image from the current image and seeing if the differnce is big, if it is then draw the webcam feed, otherwise draw the background you want. The background should be removed when you press the space bar on the keyboard. The effect should be similar to what you get with Apple's Photo Booth.

Don't worry about getting a perfect result, something like this will do:

![final](https://raw.githubusercontent.com/whg/DfPaI/master/week2/homework/backgroundSubtraction/result.jpg)
